# car detection1 > 2024-04-03 10:23pm
https://universe.roboflow.com/car-detection-dcnsx/car-detection1-n0cmv

Provided by a Roboflow user
License: CC BY 4.0

